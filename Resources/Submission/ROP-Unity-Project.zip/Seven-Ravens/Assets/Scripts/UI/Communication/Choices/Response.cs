﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Rokemon {
    


    public class Response : MonoBehaviour
    {
        public ResponseType type;
    }

}